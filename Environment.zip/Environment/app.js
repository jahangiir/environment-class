console.log("Hello");
alert("Environment JS")